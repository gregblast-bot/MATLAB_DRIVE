%This function has two inputs passed to it from main and one output into main
function [x] = HW4_Part4(A,b)
    
    %Solve the linear equation     
    x = (A^-1)*b;
    
end