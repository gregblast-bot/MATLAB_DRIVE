function [] = Plot(x,y)

%This function uses x and y as inputs
%Prompt the user for the order of the polynomial
order = input('Would you like the order of the polynomial to be 2, 3 or 4: ');
%Read in this image for future plotting
image = imread('Mid3.jpg');

%While the order is not equal to 2,3, or 4 continually prompt
%Error check is not working at the moment, commented out for the time being
% while (order ~= num2str(2)) || (order ~= num2str(3)) || (order ~= num2str(4))
%    order = input('Would you like the order of the polynomial to be 2, 3 or 4: ', 's'); 
% end

%new_x will hit the amount of data points that we are looking for
new_x = min(x):0.1:max(x);
%coeff will be used to find the new_y with use of polyval
coeff = polyfit(x,y,order);
%Find new_y with using polyval, coeff and new_x
new_y = polyval(coeff, new_x);

%Prompt the user for a title, x-axis label and y-axis label
mytitle = input('Input a title for your plot. ', 's');
myxlabel = input('Input a title for your x-axis on your plot. ', 's');
myylabel = input('Input a title for your y-axis on your plot. ', 's');

%Subplot number one for best fit data
subplot(2,2,1)
plot(x,y,'g*',new_x,new_y,'y');
title(mytitle);
xlabel(myxlabel);
ylabel(myylabel);

%Subplot number two for image
subplot(2,2,2)
imshow(image);

%Subplot number three for histogram
subplot(2,2,3)
hist(y,5);

%Use gtext in order to display plotting on any of your subplots
gtext('Plotting');



end