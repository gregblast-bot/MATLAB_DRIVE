function [] = Displayinformation()

%This function displays my name
disp('This program is being created by Gregory Wagonblast.');

end