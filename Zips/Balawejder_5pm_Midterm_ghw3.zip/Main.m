%Gregory Wagonblast, 16Oct2019, Team 2, ghw3
%Use the clear all and clc functions for clean code
clear all
clc

choice = true;
while choice == true
%Call all of my functions to main
Displayinformation();
[x,y] = LoadData();
SumAndMax(x,y);
Plot(x,y);

choice = menu('Go Again', 'Yes', 'No');
end