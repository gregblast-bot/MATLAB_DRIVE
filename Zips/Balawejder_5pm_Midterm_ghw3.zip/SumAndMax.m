function [] = SumAndMax(x,y)

%This function uses x and y as inputs
%Instantiate lengths of x and y and summie variable
n = length(x);
m = length(y);
summie = 0;

%Loop through the vector by two and find the sum
for i = 1:2:n
    summie = summie + i;
end

%Find max value of y and display
maxxie = max(y);
disp(maxxie);

%Find the x value corresponding to the max of y, not working at the moment
% for j = 1:m
%     if xid(j) == maxxie(j)
%         disp(xid);
%     end
% end
        
        
%Display the sum using num2str
disp(['The sum is: ', num2str(summie)]);
    

end