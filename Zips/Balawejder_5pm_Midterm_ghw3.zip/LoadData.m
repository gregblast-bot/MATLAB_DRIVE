function [x,y] = LoadData()

%This function outputs x and y variables
%Prompt user for the proper filename
 filename = input('Enter a file name with extension to use ', 's');
 
 %While filename is incorrect continue to prompt
 while exist(filename) == 0
     filename = input('Enter the correct file name with the correct extension to use ', 's');
 end
 
 %Load the file and declare the size of the rows and columns for future use
 fileload = load(filename);
 [rows,cols] = size(fileload);
 
 %If the matrix is 2_Dimensional we will use it, if not tell user
 if isequal([rows,cols],[rows,2])
     x = fileload(:, 1);
     y = fileload(:, 2);  
 elseif isequal([rows,cols],[2, cols])
     x = fileload(1, :);
     y = fileload(2, :);
 else
     disp('Enter A 2-Dimensional Matrix. Fo Realz!'); 
 end
 
end